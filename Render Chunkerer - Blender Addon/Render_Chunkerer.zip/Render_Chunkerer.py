bl_info = {
"name" : "Render Chunkerer",
"author" : "James Clark",
"version" : (1,2),
"blender" : (2,90,0),
"location" : "View3d > Sidebar > Render Chunkerer",
"warning" : "",
"wiki_url" : "",
"category" : "Render"
}

import bpy
from bpy.props import (BoolProperty, FloatProperty, IntProperty, StringProperty, CollectionProperty)
import os

# Assign a collection
class SceneSettingItem(bpy.types.PropertyGroup):
        
    name = bpy.props.StringProperty(name="Test Prop", default="Unknown")
    
    frame_1 : IntProperty(
        name="",
        description = "Select first frame",
        default = 0
    )
    
    frame_2 : IntProperty(
        name="",
        description = "Select second frame",
        default = 10
    )
    
    x_res : IntProperty(
        name="",
        description = "Set X Res",
        default = 100
    )
    
    y_res : IntProperty(
        name="",
        description = "Set Y Res",
        default = 100
    )
    
    ortho : BoolProperty(
        name="Orthographic",
        description = "Set Camera To Orthographic",
        default = False
    )
    

class RenderProperties(bpy.types.PropertyGroup):
   
    render_dir : StringProperty(name="")
    
bpy.utils.register_class(SceneSettingItem)
bpy.utils.register_class(RenderProperties)


    
class RenderChunkerer(bpy.types.Panel):
    bl_label = "Render Chunkerer"
    bl_idname = "RDC"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Render Chunkerer'     
    
    def draw(self, context):
        layout = self.layout
        render_sets = context.scene.render_set
        row = layout.row()
        
        row.label(text = "Render Path", icon = 'FILEBROWSER')
        row = layout.row()
        row.prop(render_sets, "render_dir")
        
        row = layout.row()  
        
        # Add/remove  
        row.scale_y = 2
        row.operator("add.ops")
        row.operator("remove.ops")  
        
        
        row = layout.row()
        
        row.scale_y = 3
        row.operator("render.ops")
        row = layout.row()  
        
        row.label(text = "Render Chunks", icon = 'RESTRICT_RENDER_OFF')
        row = layout.row()
        
        # Add the properties
        for iterator, my_item in enumerate(bpy.context.scene.my_settings):
            
            row.label(text = "")
            row.label(text = "- - - - - - Render Chunk " + str(iterator+1) + " - - - - - -")
            row.label(text = "")
            row = layout.row()
            row.label(text="First Frame:")
            row.prop(my_item, "frame_1")
            row.label(text="Second Frame:")
            row.prop(my_item, "frame_2")
            row = layout.row()
            row.label(text="X Res:")
            row.prop(my_item, "x_res")
            row.label(text="Y Res:")
            row.prop(my_item, "y_res")
            row = layout.row()
            row.prop(my_item, "ortho")            
            row = layout.row()    
            row.label(text="")
            row = layout.row() 
             
          
    
    
class AddChunk(bpy.types.Operator):
    bl_label = "Add Chunk"
    bl_idname = "add.ops"
    
    def execute(self,context):
        
        layout = self.layout
        
        my_item = bpy.context.scene.my_settings.add()
        my_item.name = "Spam"
        my_item.frame_2 = 50
        
        try:
            register()
        except:
            pass
        
        return {'FINISHED'}
    
class RemoveChunks(bpy.types.Operator):
    bl_label = "Remove Chunk"
    bl_idname = "remove.ops"
    
    def execute(self,context):
        
        if len(bpy.context.scene.my_settings) > 0:
            bpy.context.scene.my_settings.remove(len(bpy.context.scene.my_settings) -1)
        
            try:
                del bpy.types.Scene.my_settings

                del bpy.types.Scene.render_set
                register()
            except:
                pass
        
        return {'FINISHED'}
    
class Render(bpy.types.Operator):
    bl_label = "Render"
    bl_idname = "render.ops"
    
    def execute(self,context):
        
        if bpy.types.Scene.render_set != None or bpy.types.Scene.render_set != "":
            
            my_settings = context.scene.my_settings
            render_set = context.scene.render_set
        
            bpy.context.scene.render.filepath = render_set.render_dir
            
            
            
            # Render first chunk
            for render_chunk in my_settings:
                # Set orthographic or perspective
                if render_chunk.ortho:
                    bpy.data.cameras["Camera"].type = "ORTHO"
                else:
                    bpy.data.cameras["Camera"].type = "PERSP"
                            
                # Set resolution of chunk
                bpy.context.scene.render.resolution_x = render_chunk.x_res
                bpy.context.scene.render.resolution_y = render_chunk.y_res
                for frame in range(render_chunk.frame_1, render_chunk.frame_2+1):     
                    bpy.context.scene.frame_current = frame
                    bpy.context.scene.render.filepath = os.path.join(render_set.render_dir, str(frame)+".png")
                    bpy.ops.render.render(write_still=True, use_viewport=True)
        
        return {'FINISHED'}
    
classes = [RenderChunkerer,AddChunk,RemoveChunks,Render]

        
def register():
    bpy.types.Scene.my_settings = bpy.props.CollectionProperty(type=SceneSettingItem)

    bpy.types.Scene.render_set = bpy.props.PointerProperty(type=RenderProperties)

    for cls in classes:
        
        bpy.utils.register_class(cls)
    
        
        
def unregister():
    del bpy.types.Scene.my_settings

    del bpy.types.Scene.render_set

    for cls in classes:
        bpy.utils.unregister_class(cls)
        
if __name__ == "__main__":
    register()
